#include "stdio.h"

int main() {
        char s[100];

        scanf("%99s", s);

    printf(s);

    return 0;
}
