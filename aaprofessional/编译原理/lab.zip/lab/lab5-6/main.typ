#import "./template.typ": *
#import "@preview/cuti:0.2.1": show-cn-fakebold
#show: show-cn-fakebold
#set text(font: ("Times New Roman", "SimSun"))

#let title = "编译原理实验报告"
#let sub_title = (
  (name: "实验五", content: "学习Yacc并使用Bison调试"),
  (name: "实验六", content: "语法分析器的工程实践"),
)
#let author = "lzy"
#let members = (
  (name: "梁子毅", id: "22090001041"),
  (name: "庾子睿", id: "22020007135"),
  (name:"汪涛", id:"21020007089"),
  (name:"易率", id:"22090041073"),
  (name:"曹嗣弘",id:"22020007004")
)
#let pair_members = none
#let date = datetime(
  year: 2025,
  month: 5,
  day: 28,
)

#show: assign_class.with(title, sub_title,author, members, pair_members, date)

#my_heading("实验五：学习Yacc并使用Bison调试")

= 实验目的
熟悉语法分析器生成工具Yacc的使用，并学会在linux命令行下使用Bison工具编译Yacc文法说明文件。学习如何使用Lex和Yacc合作进行语法分析。

在进行本关任务时，请随时查阅《Lex使用指南》以及《Yacc使用指南》

= 实验内容
== 第一部分
- 根据给出的calculator例子（calculator0,calculator1,calculator2,calculator3，点击此处下载）完成下面题目：用lex和yacc写一个用二义文法计算布尔表达式真值的计算器。

- 右侧编辑器中已经预先给出了calculator3例子中的lex、yacc和makefile代码，该例有移进-归约冲突，无法编译成功，请自行修改代码

== 第二部分
- 根据给出的calculator例子（calculator0,calculator1,calculator2,calculator3，点击此处下载）完成下面题目：用lex和yacc写一个用非二义文法计算布尔表达式真值的计算器

- 右侧编辑器中已经预先给出了calculator3例子中的lex、yacc和makefile代码，该例有移进-归约冲突，无法编译成功，请自行修改代码

= 实验要求
== 第一部分要求
+ 输入为一个布尔表达式，以换行结束。输出为这个布尔表达式的真值（true或false）。

+ 布尔表达式二义文法为：S –> S or S | S and S | not S | (S) | true | false，其中优先级or < and < not，or 和 and 左结合，not 右结合。

+ 在命令行下用flex，bison和gcc工具将实验调试通过，编译出可执行文件，并通过系统的测试用例检测。

=== 测试输入：
```shell
true or false and false and not (false or false)
```

=== 预期输出：
```shell
true
```

== 第二部分要求
- 输入为一个布尔表达式，以换行结束。输出为这个布尔表达式的真值（true或false）。

- 布尔表达式二义文法为：S –> S or S | S and S | not S | (S) | true | false，其中优先级or < and < not，or 和 and 左结合，not 右结合。非二义文法请参照表达式非二义文法自己写出来。

- 在命令行下用flex，bison和gcc工具将实验调试通过，编译出可执行文件，并通过系统的测试用例检测

=== 测试输入：
```shell
true or false and false and not (false or false)
``` 

=== 预期输出：
```shell
true
```

= 实验过程及重点内容
== 第一部分
- 使用非二义性文法进行书写，即需要定义优先级来避免出现二义性（这里即使不定义也不一定能通过测试用例）
- 通过阅读yacc和lex的文档，讲or、and、not等符号定义为token，并设置优先级
- 在yacc文件中定义文法规则，使用%left和%right来设置运算符的优先级和结合性
- 在lex文件中定义词法中声明or、and、not等符号的正则表达式，并返回相应的token



== 第二部分
- 使用非二义性文法进行书写，从文法上避免出现二义性
- 将原来的文法进行拆解，使用非终结符来表示不同的运算符和操作数
- 核心文法如下：
  ```c
  expr   : expr OR term          { $$ = $1 || $3; }   
          | term                 { $$ = $1; }         
          ;

  term   : term AND factor      { $$ = $1 && $3; }   
          | factor               { $$ = $1; }         
          ;

  factor : NOT factor           { $$ = !$2; }        
          | LPAREN expr RPAREN  { $$ = $2; }         
          | TRUE                { $$ = 1.0; }        
          | FALSE               { $$ = 0.0; }        
          ;
  ```

= 实验结果
== 第一部分
#figure(
  image("figure/lab5_part1_result.png", width: auto),
  caption: "实验五第一部分运行结果"
)
- 第一部分重点代码如下
  + 在test5-1.l中加入true和false的定义
    ```c
      %{
      #include "test5-1.tab.h"

      int yywrap(void){
        return 1;
      }
      %}

      ws			[ \t]
      digit	 	[0-9]


      %%
      "true"      { yylval = 1; return TRUE; }
      "false"     { yylval = 0; return FALSE; }
      "("			{return LPAREN;}
      ")"			{return RPAREN;}
      "and"   {return AND;}
      "or"    {return OR;}
      "not"   {return NOT;}

      {ws}		{;}
      "\n"		{return ENTER;}
      .				{printf("\nLEX:ERROR! c=%s\n", yytext);}
    ```
  + 在test5-1.y中写下二义性文法
    ```c
    %{
      #include <stdio.h>
      int yylex();
      #define YYSTYPE double /* 将Yacc栈定义为double类型 */
      int yyerror(char *);   /* 不声明该函数将出现warning */
    %}

    %token LPAREN RPAREN ENTER NOT AND OR TRUE FALSE
    %left OR
    %left AND
    %right NOT

    %%

    /* 这样写prog可以让分析器每次读入一行进行分析，下一行重新分析expr */
    prog : prog exprp
        | exprp
        ;

    /* exprp 	: expr ENTER {printf("\nThe value of the expression is %d.\n", $1);} */
    exprp:
        expr ENTER { printf("%s\n", $1 ? "true" : "false"); }
        ;
    expr  : expr OR expr {$$ = $1 || $3;}
            | expr AND expr {$$ = $1 && $3;}
            | NOT expr {$$ = !$2;}
        | LPAREN expr RPAREN {$$ = $2;}
        | TRUE              { $$ = 1; }
        | FALSE             { $$ = 0; }	
        ;


    %%

    int main(){
      yyparse();
      return 0;
    }


    ```

== 第二部分
#figure(
  image("figure/lab5_part2_result.png", width: auto),
  caption: "实验五第二部分运行结果"
)

- 使用非二义性文法进行书写
  ```c
    %{
      #include <stdio.h>
      int yylex();
      #define YYSTYPE double /* 将Yacc栈定义为double类型 */
      int yyerror(char *);   /* 不声明该函数将出现warning */
    %}

    %token LPAREN RPAREN ENTER NOT AND OR TRUE FALSE


    %%

    /* 这样写prog可以让分析器每次读入一行进行分析，下一行重新分析expr */
    prog : prog exprp
        | exprp
        ;

    /* exprp 	: expr ENTER {printf("\nThe value of the expression is %d.\n", $1);} */
    exprp:
        expr ENTER { printf("%s\n", $1 ? "true" : "false"); }
        ;
    /* 非终结符定义 */
    expr   : expr OR term          { $$ = $1 || $3; }   /* S → S or T */
            | term                 { $$ = $1; }         /* S → T */
            ;

    term   : term AND factor      { $$ = $1 && $3; }   /* T → T and F */
            | factor               { $$ = $1; }         /* T → F */
            ;

    factor : NOT factor           { $$ = !$2; }        /* F → not F */
            | LPAREN expr RPAREN  { $$ = $2; }         /* F → (S) */
            | TRUE                { $$ = 1.0; }        /* F → true */
            | FALSE               { $$ = 0.0; }        /* F → false */
        ;


    %%

    int main(){
      yyparse();
      return 0;
    }
  ```

= 实验中遇到的问题、难点及解决方案
== 第一部分
// TODO: yzr
#cprob[使用二义文法编写计算器时，代码存在移进 - 归约冲突导致无法编译成功。][将 or、and、not 等符号定义为 token 并设置优先级，在 Yacc 文件中定义文法规则，运用 %left 和 %right 来明确运算符的优先级和结合性，从而消解了二义性。

]

== 第二部分
// TODO: yzr
#cprob[第二关不知道如何从文法上避免二义性。][将文法进行拆解，使用非终结符来表示不同的运算符和操作数。定义了 expr、term、factor 等非终结符，通过层级结构来明确运算的优先级和结合性，准确解析了布尔表达式并计算出正确的真值。

]

= 感想和收获
实验五 “学习 Yacc 并使用 Bison 调试” 的过程中，第一部分使用二义文法面对移进 - 归约冲突的问题，我们小组运用 `%left` 和 `%right` 来设定运算符优先级和结合性，解决了冲突。第二部分采用非二义文法时，将文法拆解为 expr、term、factor 等非终结符，明白了如何从文法层面避免二义性，使程序更加高效准确。同时，整个实验还锻炼了我们小组在 Linux 命令行下使用 flex、bison 和 gcc 工具进行调试和编译的能力。

= 小组分工情况
- 梁子毅：
  - 主要任务：统筹实验进度，整合编写实验报告，编写实验内容和实验重点内容
  - 辅助任务：完善实验报告细节部分

- 曹嗣弘：
  - 主要任务：思考总结实验中出现的问题和难点，并撰写解决方案，并且讨论分析

- 汪涛：
  - 主要任务：思考实验中的代码细节，并且讨论分析

- 易率：
  - 主要任务：完成对实验五的代码讨论，思路分享
  - 辅助任务：实验五的实验过程和实验中遇到的问题、难点及解决方案书写

- 庾子睿：
  - 主要任务：实验五遇到的问题和难点及解决方案书写
  - 辅助任务：实验五的实验内容和实验重点内容书写


/***   PART II    ***/
#my_heading("实验六：语法分析器的工程实践")

= 实验目的
== 第一部分
熟悉语言SUM 到栈式计算机STACK的机器语言的翻译过程，理解编译的一般步骤

== 第二部分
熟悉语言SUM 到栈式计算机STACK的机器语言的翻译过程，理解编译的一般步骤

== 第三部分
加深对递归下降的预测分析法的理解


= 实验内容
== 第一部分
- 我们的代码仓库里已经准备好了一个名为sum.c的源文件.

- sum.c是用c语言写的从sum语言到栈式计算机STACK的机器语言的编译器（省略了词法语法分析部分）。该程序的基本功能是先构造SUM语言的某句子的抽象语法树，然后将该语法树翻译成STACK的机器语言程序，并按顺序打印出该机器语言程序的指令。

- 程序中有两段内容不完整（在程序中用函数TODO()表示），请读懂并修改该程序，将TODO的部分补充完整，并通过本节的测试用例。


== 第二部分
- 我们的代码仓库里已经准备好了一个名为sum.c的源文件，与第1关相同。因此，你可以直接把第1关中TODO()部分的通关代码复制过来。

- 在第1关任务的基础上，将程序中的简单表达式改成从外部输

== 第三部分
- 给定语言L(G)，为其写一个递归下降的预测分析器，用以判定某个句子是否是语言L(G)中的句子

- 语言L(G)是个表示加法表达式的语言，加法左结合，表达式中可以有整型数，加法，小括号。L(G)的一个文法G如下： G -> num | G+G | (G) 该语言中句子的例子：1+(2+3) 以换行表示句子的结束

- 我们的代码仓库里已经准备好了一个名为sumplus.c的源文件。sumplus.c是一个程序框架，已提供了词法分析器yylex()，可以在该框架基础上改写，也可以删掉内容自己写。请直接在该文件里编写代码


= 实验要求
== 第一部分
- 读懂程序sum.c并尝试自测运行，查看输出结果。

- 用你自己写的程序段替换程序中的TODO部分，使程序功能与实验内容的描述一致。

=== 预期输出：
```shell
预期输出：

Compile starting
the expression is:
((2+3)+4)
The stack instruction list is:
PUSH 2
PUSH 3
ADD
PUSH 4
ADD
Compile finished
```

== 第二部分
- 在第1关任务的基础上，利用sum.c中的Read_ast()函数，将程序改为从外部输入抽象语法树。

- 为了简便起见，输入的抽象语法树使用前缀表示法，所有的数值均为整数。数值间以空格隔开。如1+(2+3)的抽象语法树输入为+1+2 3。

- 你的程序应能通过本节中的所有测试用例。

=== 测试输入：
```shell
++2 3 4
```
=== 预期输出：
```shell
Compile starting
the expression is:
((2+3)+4)
The stack instruction list is:
PUSH 2
PUSH 3
ADD
PUSH 4
ADD
Compile finished
```

== 第三部分
+ 读懂程序sumplus.c并尝试自测运行，查看输出结果

+ 对文法G做修改，使其能够适用于递归下降的预测分析（注意语言不能改）

+ 用你自己写的程序段替换expr()中的TODO()函数，并自行增加其他必要的函数，使程序功能与实验内容的描述一致， 也可以删掉内容自己写

+ 你的程序应能通过本节中的所有测试用例

== 测试输入：
```shell
1+(2+3)
``` 

== 预期输出：
```shell
NUM(1) PLUS LPAREN NUM(2) PLUS NUM(3) RPAREN ENTER
Parsing Success!
```

= 实验过程及重点内容
== 第一部分
 1. 首先，打开并阅读 sum.c 文件，了解该程序如何用抽象语法树（AST）表示 SUM 语言的加法表达式，以及整体的编译流程。
 2. 在代码中找到标记为 TODO 的部分，分析这两处需要实现的功能，通常涉及 AST 的遍历与指令输出。
 3. 按照实验要求，补全 TODO 部分的代码：在遍历语法树时，若当前节点是整数类型，则输出对应的 PUSH 指令；若当前节点是加法类型，则输出 ADD 指令，实现表达式到栈机指令的正确转换。
 4. 补全代码后，保存并运行程序，观察程序输出的 STACK 指令顺序是否与实验说明中的预期输出一致。
 5. 最后，确认程序输出符合要求，即可完成本部分实验内容。

== 第二部分
 1. 继续使用 sum.c 文件，将原本写死的表达式输入方式改为从外部读取输入。
 2. 阅读并理解 Read_ast() 函数，掌握如何通过前缀表达式输入来构建抽象语法树（AST）。
 3. 按照要求，输入的表达式使用前缀表示法，整数和符号之间用空格分隔，例如 `++2 3 4`。
 4. 程序读取输入后，利用 Read_ast() 构建 AST，并按照第一关的思路遍历语法树，输出对应的 STACK 指令（整数输出 PUSH，遇到加法输出 ADD）。
 5. 运行程序，输入测试用例，检查输出的 STACK 指令序列是否与实验说明中的预期结果一致。
 6. 确认程序能够正确处理不同的前缀表达式输入，并输出符合要求的机器语言指令序列。

== 第三部分
1. 阅读 sumplus.c 文件，了解程序的结构和词法分析器 yylex() 的用法，熟悉输入和输出的格式要求。
2. 分析给定的文法 G（G -> num | G+G | (G)），发现其存在左递归，不适合直接用于递归下降分析。对文法进行改写，消除左递归，使其适合递归下降实现，但保证语言本身不变。
3. 在 expr() 函数的 TODO 部分，补全递归下降分析的核心代码，并根据需要增加辅助函数，实现对表达式的预测分析。
4. 程序运行时，调用 yylex() 获取下一个词法单元，根据当前词法单元决定分析动作，遇到数字、加号、小括号等按规则递归分析，遇到错误或不符文法时输出错误信息。
5. 编写和完善分析成功与失败的输出格式，确保输出与实验要求一致（如“Parsing Success!” 或 “Parsing Fail!”）。
6. 保存并运行程序，输入不同的表达式测试用例，检查分析器能否正确判断输入句子是否符合文法 G，并输出正确的分析过程和结果。

= 实验结果
== 第一部分
#figure(
  image("figure/lab6_part1_result.png", width: 50%),
  caption: "实验六第一部分运行结果"
)

```c
void List_reverse_print(struct List_t *list) {
    if (!list) return;
    List_reverse_print(list->next);
    switch (list->instr->kind) {
        case STACK_ADD:
            printf("ADD\n");
            break;
        case STACK_PUSH: {
            struct Stack_Push *p = (struct Stack_Push *)list->instr;
            printf("PUSH %d\n", p->i);
            break;
        }
        default:
            break;
    }
}
```
递归实现`List_reverse_print`函数，遍历链表并逆序打印指令。

```c
case EXP_SUM: {
    struct Exp_Sum *p = (struct Exp_Sum *)exp;
    compile(p->left);
    compile(p->right);
    emit(Stack_Add_new());
    break;
}
```
在编译加法表达式时，递归调用`compile`函数处理左右子表达式，并生成对应的栈指令。


== 第二部分
#figure(
  image("figure/lab6_part2_result.png", width: 50%),
  caption: "实验六第二部分运行结果"
)

```c
struct Exp_t* Read_ast()
{
    int token, value;
    token = yylex(&value);
    if (token == NUM) {
        // 读取到数字，构造叶子节点
        return Exp_Int_new(value);
    } else if (token == PLUS) {
        // 读取到加号，递归读取左右子树
        struct Exp_t* left = Read_ast();
        struct Exp_t* right = Read_ast();
        return Exp_Sum_new(left, right);
    } else if (token == ENTER) {
        // 输入结束
        return NULL;
    } else {
        printf("Parse error: unexpected token\n");
        return NULL;
    }
}
```
在`Read_ast`函数中，使用`yylex`读取前缀表达式的词法单元，根据不同的符号构造相应的抽象语法树节点。

== 第三部分
#figure(
  image("figure/lab6_part3_result.png", width: auto),
  caption: "实验六第三部分运行结果"
)

```c
// 前向声明
int expr();
int exprp();
int term();

// expr -> term exprp
int expr() {
    if (!term()) return 0;
    return exprp();
}

// exprp -> + term exprp | ε
int exprp() {
    if (lookahead == PLUS) {
        match(PLUS);
        if (!term()) return 0;
        return exprp();
    }
    // ε
    return 1;
}

// term -> (expr) | NUM
int term() {
    if (lookahead == NUM) {
        match(NUM);
        return 1;
    } else if (lookahead == LPAREN) {
        match(LPAREN);
        if (!expr()) return 0;
        if (!match(RPAREN)) return 0;
        return 1;
    } else {
        printError(lookahead);
        return 0;
    }
}
```
在递归下降分析器中，使用`expr`、`exprp`和`term`函数实现对加法表达式的预测分析，处理数字、加法和括号。

= 实验中遇到的问题、难点及解决方案
== 第一部分
// TODO: yzr
#cprob[不知道怎么遍历抽象语法树生成指令
  
][使用深度优先遍历的方式来递归地编译抽象语法树。对于每个加法节点，先编译左子树和右子树，然后发射一个加法指令。
  
]
#cprob[不知道怎么将生成的指令链表反转打印][使用一个链表来保存生成的指令，最后通过递归的方式从尾部到头部打印链表，实现指令的正确顺序。]
== 第二部分
#cprob[不知道如何解析前缀表示法的输入并构建抽象语法树。
  
][编写 Read_ast() 函数，使用递归下降解析方法来解析前缀表达式。遇到加号时，递归解析左子表达式和右子表达式。
]
#cprob[处理输入中的整数和加号时出现错误
  
][使用词法分析器 yylex() 来获取输入的词法单元，在解析过程中处理整数和加号。
]
== 第三部分
#cprob[运行时发现非法字符和语法错误。][遇到非法字符时添加错误处理逻辑只打印一次错误信息，然后跳过当前行的剩余字符避免重复打印。]

   
= 感想和收获
// TODO: yzr
一开始面对如何遍历抽象语法树生成指令时，一度被卡了很久，后来组员想到可以通过采用深度优先遍历的方式递归地编译加法节点的左右子树并发射加法指令；在将指令链表反转打印时，ys同学想到链表结合递归从尾部到头部打印。第二部分解析前缀表示法并构建抽象语法树时，我们用一个 Read_ast () 函数递归下降解析方法剖析前缀表达式，并在处理输入整数和加号错误。整体而言，实验六锻炼了我们组的问题解决能力和沟通能力，让我们小组在沟通效率上又有了一个大迈步。


= 小组分工情况
- 梁子毅：
  - 主要任务：统筹实验进度，整合编写实验报告
  - 辅助任务：完善实验报告细节部分

- 曹嗣弘：
  - 主要任务：思考总结实验中出现的问题和难点，并撰写解决方案

- 汪涛：
  - 主要任务：思考实验中的代码细节

- 易率：
  - 主要任务：实验六的实验内容和实验重点内容书写

  - 辅助任务：实验六的实验过程和实验中遇到的问题、难点及解决方案书写

- 庾子睿：
  - 主要任务：实验六的实验遇到的问题和难点及解决方案书写
  - 辅助任务：实验六的实验内容和实验重点内容书写