#include "stdio.h"

int main(int argc,char *argv[]) {
    // Print an empty string
    printf("%d, %d, %d\n");
    return 0;
}