#import "./template.typ": *
#import "@preview/cuti:0.2.1": show-cn-fakebold
#show: show-cn-fakebold
#set text(font: ("Times New Roman", "SimSun"))

#let title = "编译原理实验报告"
#let sub_title = (
  (name: "实验七", content: "用Lex和Yacc设计语法分析器1"),
  (name: "实验八", content: "用Lex和Yacc设计语法分析器2"),
)
#let author = "lzy"
#let members = (
  (name: "梁子毅", id: "22090001041"),
  (name: "庾子睿", id: "22020007135"),
  (name:"汪涛", id:"21020007089"),
  (name:"易率", id:"22090041073"),
  (name:"曹嗣弘",id:"22020007004")
)
#let pair_members = none
#let date = datetime(
  year: 2025,
  month: 6,
  day: 18,
)

#show: assign_class.with(title, sub_title,author, members, pair_members, date)

#my_heading("【实验七】用Lex和Yacc设计语法分析器1
")
= 实验目的
学习如何使用Yacc设计一个语法分析器，并与用lex写的词法分析器链接起来

= 实验内容
- 使用yacc为实验3所给的语言写一个语法分析器（你可以重新设计该语言的文法，但不能改变语言）。

- 其中，词法分析使用实验4中已完成的词法分析器（即，你需要将本实验的语法分析器和实验4的词法分析器链接起来）
= 实验要求
+ 在本实验已有代码文件（见代码文件说明）的基础上，完善语法分析器parser.y并进行编译，能够正确响应输入内容，并输出预期结果：输入为一段源程序文本；输出语法分析是否成功的提示（“Parse Successful!”或“Parse Failed!”）。

+ 在语法分析中不能出现任何的冲突（移进-归约或归约-归约冲突），或者虽然有冲突，但是你能够说清楚冲突是如何解决的。

+ 可以在本实验已有代码文件（见代码文件说明）的基础上修改，也可以自行修改这些代码文件的内容。如果你尚不能将实验3的词法分析器和本实验的语法分析器链接起来，可以暂时使用已有文件lex.yy.c中给出的词法分析器（前提是你的语法分析器中终结符名的定义与该例子中的终结符定义相同）。

+ 你的程序应能通过本节中的所有测试用例。

= 实验过程及重点内容
- Token一致性：确保parser.l返回的token值（如PROGRAM, BEGINN等）与parser.y中的%token定义完全匹配

- 数据传递：通过yylval传递词法属性

- 移进-归约冲突（悬空else问题）：

  - 冲突位置：IF condition THEN statement遇到ELSE时

  - 解决方案：明确指定优先级
- parser.y
```
%{
#include <stdio.h>
#include "util.h" 
#include "errormsg.h"


int yylex(void); /* function prototype */

/* 该函数显示错误信息s，显示时包含了错误发生的位置。*/
void yyerror(char *s)
{
 EM_error(EM_tokPos, "%s", s);
}


%}


 /* 定义属性值栈的类型，后续实验中如果需要存储不同类型的属性值，则需要修改此处 */
%union {
	int ival;
	double fval;
	string sval;
}

 /* 定义各个终结符，以及他们的属性值的类型，后续实验中如果需要存储不同类型的属性值，则需要修改此处 */
%token <sval> ID /* id */
%token <ival> INT  /*整型数*/
%token <fval> FLOAT /*浮点数*/
%token INTEGER REAL  /*两种类型名：整型、实型*/
%token 
  COMMA COLON SEMICOLON LPAREN RPAREN PERIOD /* 符号 , : ; ( ) . */
  PROGRAM BEGINN END VAR IF WHILE DO   /* 关键字：PROGRAM BEGIN END VAR IF WHILE DO */
  /* 想想为什么不声明为BEGIN？ */
  THEN ELSE /* 关键字：THEN ELSE */
  ASSIGN EQ NEQ LT LE GT GE /* 符号 :=	 =  <>  <  <=  >  >= */
  PLUS MINUS TIMES DIVIDE /* 符号 + = * / */
%start program /* 开始符号为program */



%debug /* 允许跟踪错误 */

%%
 /* 文法：program--> PROGRAM ID; vardec BEGIN stmts END. 
  *       vardec-->   VAR declist 
  *       declist-->  ID:INTEGER;
  *       stmts--> ID := exp
  *       exp--> INT
  *
  * 后续实验可能需要修改这个文法
  */
program
    : PROGRAM ID SEMICOLON block PERIOD
    ;

block
    : var_decl_part BEGINN statements END
    ;

var_decl_part
    :  VAR var_decl_list SEMICOLON
    ;

var_decl_list
    : var_decl 
    | var_decl_list SEMICOLON var_decl
    ;

var_decl
    : id_list COLON type
    ;

id_list
    : ID
    | id_list COMMA ID
    ;

type
    : INTEGER
    | REAL
    ;

statements
    : statement
    | statements SEMICOLON statement
    ;

statement
    : assignment
    | if_statement
    | while_statement
    | compound_statement
    ;

compound_statement
    : BEGINN statements END
    ;

assignment
    : ID ASSIGN expression
    ;

if_statement
    : IF condition THEN statement ELSE statement
    | IF condition THEN statement
    ;

while_statement
    : WHILE condition DO statement
    ;

condition
    : expression relop expression
    ;

relop
    : EQ
    | NEQ
    | LT
    | LE
    | GT
    | GE
    ;

expression
    : expression PLUS term
    | expression MINUS term
    | term
    ;

term
    : term TIMES factor
    | term DIVIDE factor
    | factor
    ;

factor
    : ID
    | INT
    | FLOAT
    | LPAREN expression RPAREN
    ;

%%
```

- parser.l
```
%{
#include "parser.tab.h"
#include <stdio.h> 
#define LT					1
#define	LE					2
#define GT					3
#define	GE					4
#define	EQ					5
#define NE					6

#define WHILE				18
#define	DO					19
#define ID          20
#define NUMBER      21
#define RELOP       22

#define NEWLINE     23
#define ERRORCHAR   24

#define PROGRAM 25
#define SEMICOLON 26
#define VAR 27
#define INTEGER 28 //int标识
#define FLOAT 29 //浮点数
#define ASSIGN 30
#define BEGINN 31
#define END 32
#define PERIOD 33
#define COLON 34
#define REAL 35
#define INT 37 //整数
#define IF 38
#define THEN 39
#define ELSE 40
#define PLUS 41
#define MINUS 42
#define TIMES 43
#define DIVIDE 44
#define COMMA 45


typedef union {
    char* str_val;
    int int_val;
    double float_val;
} YYSTYPE;

YYSTYPE yylval;

%}
delim		[ \t \n]
ws			{delim}+
letter	[A-Za-z]
digit		[0-9]
id			{letter}({letter}|{digit})*
number	{digit}+(\.{digit}+)?(E[+-]?{digit}+)?


%s COMMENT

%%

<INITIAL>"/*"						{BEGIN COMMENT;}
<COMMENT>"*/"						{BEGIN INITIAL;}
<COMMENT>.|\n						{;}

 /* ECHO是一个宏，相当于 fprintf(yyout, "%s", yytext)*/

<INITIAL>{ws}	          {;}
<INITIAL>"IF"					{return (IF);}
<INITIAL>"THEN"					{return (THEN);}
<INITIAL>"ELSE"					{return (ELSE);}
<INITIAL>"WHILE"					{return (WHILE);}
<INITIAL>"DO"		          {return (DO);}
<INITIAL>"PROGRAM"		          {return (PROGRAM);}
<INITIAL>"BEGIN"		          {return (BEGINN);}
<INITIAL>"VAR"		          {return (VAR);}
<INITIAL>"INTEGER"		          {return (INTEGER);}
<INITIAL>"REAL"		          {return (REAL);}
<INITIAL>"END"		          {return (END);}
<INITIAL>":="		          {return (ASSIGN);}
<INITIAL>":"		          {return (COLON);}
<INITIAL>"+"		          {return (PLUS);}
<INITIAL>"-"		          {return (MINUS);}
<INITIAL>"*"		          {return (TIMES);}
<INITIAL>"/"		          {return (DIVIDE);}
<INITIAL>","		          {return (COMMA);}
<INITIAL>{id}	          {yylval.str_val = strdup(yytext);return (ID);}
<INITIAL>([1-9]{digit}*|0)	      {yylval.int_val = atoi(yytext);return (INT);}
<INITIAL>({digit}+\.{digit}*|\.{digit}+)	      {yylval.float_val = atof(yytext);return (FLOAT);}
<INITIAL>"<"	          {return (LT);}
<INITIAL>"<="	          {return (LE);}
<INITIAL>"="	          {return (EQ);}
<INITIAL>"<>"	          {return (NE);}
<INITIAL>">"	          {return (GT);}
<INITIAL>">="	          {return (GE);}
<INITIAL>";"              {return (SEMICOLON);}
<INITIAL>"."              {return (PERIOD);}
<INITIAL>.							{return ERRORCHAR;}

 
%%

int yywrap (){
  return 1;
}
void resetLexState(){
  BEGIN INITIAL;
}
void writeout(int c){
  switch(c){
  	case ERRORCHAR: fprintf(yyout, "(ERRORCHAR, \"%s\") ", yytext);break;
  	case RELOP: fprintf(yyout, "(RELOP, \"%s\") ", yytext);break;  	  
    case WHILE: fprintf(yyout, "(WHILE, \"%s\") ", yytext);break;
    case DO: fprintf(yyout, "(DO, \"%s\") ", yytext);break;
    case NUMBER: fprintf(yyout, "(NUM, \"%s\") ", yytext);break;
    case ID: fprintf(yyout, "(ID, \"%s\") ", yylval.str_val);break;
    case NEWLINE: fprintf(yyout, "\n");break;
    case PROGRAM: fprintf(yyout, "(PROGRAM, \"%s\") ", yytext);break;
    case SEMICOLON: fprintf(yyout, "(SEMICOLON, \"%s\") ", yytext);break; 
    case VAR: fprintf(yyout, "(VAR, \"%s\") ", yytext);break; 
    case BEGINN: fprintf(yyout, "(BEGIN, \"%s\") ", yytext);break;  
    case ASSIGN: fprintf(yyout, "(ASSIGN, \"%s\") ", yytext);break;
    case INT: fprintf(yyout, "(INT, \"%d\") ", yylval.int_val);break;
    case END: fprintf(yyout, "(END, \"%s\") ", yytext);break;
    case PERIOD: fprintf(yyout, "(PERIOD, \"%s\") ", yytext);break;
    case FLOAT: fprintf(yyout, "(FLOAT, \"%f\") ", yylval.float_val);break;
    case COLON: fprintf(yyout, "(COLON, \"%s\") ", yytext);break;
    case INTEGER: fprintf(yyout, "(INTEGER, \"%s\") ", yytext);break;
    case IF: fprintf(yyout, "(IF, \"%s\") ", yytext);break;
    case THEN: fprintf(yyout, "(THEN, \"%s\") ", yytext);break;
    case ELSE: fprintf(yyout, "(ELSE, \"%s\") ", yytext);break;
    case PLUS: fprintf(yyout, "(PLUS, \"%s\") ", yytext);break;
    case MINUS: fprintf(yyout, "(MINUS, \"%s\") ", yytext);break;
    case TIMES: fprintf(yyout, "(TIMES, \"%s\") ", yytext);break;
    case DIVIDE: fprintf(yyout, "(DIVIDE, \"%s\") ", yytext);break;
    case COMMA: fprintf(yyout, "(COMMA, \"%s\") ", yytext);break;
    case LE: fprintf(yyout, "(LE, \"%s\") ", yytext);break;
    case LT: fprintf(yyout, "(LT, \"%s\") ", yytext);break;
    case EQ: fprintf(yyout, "(EQ, \"%s\") ", yytext);break;
    case NE: fprintf(yyout, "(NE, \"%s\") ", yytext);break;
    case GE: fprintf(yyout, "(GE, \"%s\") ", yytext);break;
    case GT: fprintf(yyout, "(GT, \"%s\") ", yytext);break;
    case REAL: fprintf(yyout, "(REAL, \"%s\") ", yytext);break;
    default:break;
  }
  return;
}
```


= 实验结果
#figure(
  image("figure/lab7_result.png", width: 100%),
  caption: "实验七运行结果"
)

= 实验中遇到的问题、难点及解决方案
// TODO:yzr
#cprob[Yacc/Bison 生成的语法分析器中存在冲突。][调整了文法优先级和结合性规则解决了冲突。]
#cprob[词法分析器在遇到非法字符时无法正确处理。][在词法分析器中增加对非法字符的识别，并调用 yyerror 函数报告错误。]
#cprob[一开始没注意这个实验相较之前注释的定义改了，需要支持以 (* 开始、*) 结束的注释。][在词法分析器中重新修改了注释规则，以注释处理规则，(* 开始、*) 结束，让编译器在编译时跳过注释内容。]
#cprob[刚开始复制粘贴前面实验的代码，没注意到词法分析器和语法分析器之间的 token 定义不一致，找了好久的报错原因。][确保词法分析器和语法分析器中 token 的定义一致，并且在词法分析器中正确返回 token，最终解决]


= 感想和收获
// TODO:yzr
在本次实验中，我们小组深刻体会到了编译器设计的复杂性和趣味性。通过这次实验，我们全小组成员不仅都学会了如何使用 Lex 和 Yacc 工具编写词法分析器和语法分析器，还掌握了如何处理文法冲突、非法字符以及调试语法分析器等实际问题。实验过程中，小组成员逐渐理解了编译原理的核心概念，如文法的 LALR(1) 特性、token 的识别与处理、语法规则的递归定义等。遇到诸如语法冲突、非法字符识别错误、注释处理错误等问题时，我们通过上网查Lex和Yacc手册一步步解决报错，这不仅提升了我们小组成员的调试能力，也让我们对编译器的内部工作机制有了更深入的认识。此外我们还学会了如何分析测试结果并据此调整编译器的实现，对编译器的前端设计有了系统的理解，为我今后在编译技术领域的进一步学习和实践奠定了坚实的基础。

= 小组分工情况
// TODO
- 梁子毅：
  - 统筹实验进度，整合编写实验报告
  - 实验重点内容的编写

- 易率：
  - 实验重点内容的编写

- 庾子睿：
  - 问题和感想内容的撰写

- 曹嗣弘：
  - 实验细节思考，完善代码

- 汪涛：
  - 验证输出格式是否符合要求 ，修复未闭合引号、多行字符串等边界问题

/***   PART II    ***/
#my_heading("【实验八】用Lex和Yacc设计语法分析器2")

= 实验目的
学习如何使用Yacc设计一个语法分析器，并与用lex写的词法分析器链接起来

= 实验内容
- 修改实验7，给产生式加上动作，动作为生成一棵语法分析树。这棵分析树的结构可以使用或参照本实验已有代码文件（见代码文件说明）中ast.h文件中定义的分析树结构

= 实验要求
+ 在本实验已有代码文件（见代码文件说明）的基础上，完善词法分析器parser.l和语法分析器parser.y并进行编译，能够正确响应输入内容，并输出预期结果：输入为一段源程序文本；输出为一棵语法分析树。你可以在自己的语法分析器中直接使用prast.c已经提供的输出方式（打印分析树的数据结构），但前提是你必须使用ast.h提供的分析树结构。

+ 在语法分析中不能出现任何的冲突（移进-归约或归约-归约冲突），或者虽然有冲突，但是你能够说清楚冲突是如何解决的。

+ 可以在本实验已有代码文件（见代码文件说明）的基础上修改，也可以自行修改这些代码文件的内容。如果你尚不能将实验4的词法分析器和本实验的语法分析器链接起来，可以暂时使用已有文件lex.yy.c中给出的词法分析器（前提是你的语法分析器中终结符名的定义与该例子中的终结符定义相同）。

+ 你的程序应能通过本节中的所有测试用例

= 实验过程及重点内容
本实验的核心任务是基于已有的 Tiger 编译器前端框架，利用 Lex（Flex）和 Yacc（Bison）工具，设计并实现一个能够生成抽象语法树（AST）的语法分析器。实验过程及重点内容如下：
 1. 分析与理解已有代码结构
首先阅读并理解实验提供的各个代码文件，包括 `ast.h`、`ast.c`、`parser.l`、`parser.y` 等，明确抽象语法树的数据结构和各构造函数的功能。
 2. 完善抽象语法树构造函数
在 `ast.c` 中补全并修正了各类节点的构造函数，确保与 `ast.h` 中的数据结构完全匹配，特别是二元表达式、布尔表达式、if/while/seq 语句等。
 3. 编写和完善词法分析器 `parser.l`
根据实验语言的文法规范，编写了关键字、标识符、数字、运算符、分隔符等的正则规则，并正确设置 token 类型和 yylval 的赋值，保证与 `parser.y` 的 token 声明一致。
 4. 扩展语法分析器 `parser.y`
 ▫ 实现了变量声明、赋值、while、if、复合语句（BEGIN…END）等语法规则，所有产生式均加入了构造语法树的动作。
 ▫ 为赋值语句、while、if、复合语句等均调用了对应的 AST 构造函数。
 ▫ 采用递归和分号作为语句分隔符的写法，使得最后一条语句分号可选，兼容 Pascal 风格和平台测试用例。
 ▫ 支持表达式的加减乘除、括号、变量、整型、实型等。
 5. 调试与测试
 ▫ 使用 `make` 命令对项目进行编译，解决编译过程中出现的类型不匹配、成员名错误等问题。
 ▫ 通过平台自测与评测按钮，使用多组测试用例（包括最后一条语句无分号的情况）验证语法分析器的正确性和健壮性。
 ▫ 重点关注语法冲突（如 reduce/reduce 或 shift/reduce），通过调整文法和分隔符设计，保证语法分析无冲突。
 6. 结果输出与分析
 ▫ 语法分析成功后，利用 `prast.c` 提供的打印函数输出抽象语法树，便于验证语法树结构的正确性。

本实验重点在于将文法规则与抽象语法树的结构设计紧密结合，并通过 Lex 和 Yacc 的自动化工具链，实现了语法分析自动化和语法树的自动构建。

= 实验结果
本实验通过修改和完善 `ast.c`、`parser.l`、`parser.y` 等文件，实现了一个能够正确生成抽象语法树的语法分析器。以下为关键代码片段：
```c
// ast.c 关键构造函数
a_exp A_OpExp(a_pos pos, a_op op, a_exp left, a_exp right) {
  a_exp ret = checked_malloc(sizeof(*ret));
  ret->kind = A_opExp;
  ret->pos = pos;
  ret->exp.biopExp.op = op;
  ret->exp.biopExp.left = left;
  ret->exp.biopExp.right = right;
  return ret;
}
a_bexp A_BExp(a_pos pos, a_bop bop, a_exp left, a_exp right) {
  a_bexp ret = checked_malloc(sizeof(*ret));
  ret->pos = pos;
  ret->bexp.bop = bop;
  ret->bexp.left = left;
  ret->bexp.right = right;
  return ret;
}
```
```yacc
// parser.y 部分关键文法
stmts
  : stmts SEMICOLON stm
      {
        a_stm_list tail = $1;
        while (tail->tail) tail = tail->tail;
        tail->tail = A_StmList($3, NULL);
        $$ = $1;
      }
  | stm { $$ = A_StmList($1, NULL); }
  ;

stm
  : ID ASSIGN exp { $$ = A_Assign(EM_tokPos, A_Id(EM_tokPos, $1), $3); }
  | WHILE bexp DO stm { $$ = A_While(EM_tokPos, $2, $4); }
  | IF bexp THEN stm ELSE stm { $$ = A_If(EM_tokPos, $2, $4, $6); }
  | IF bexp THEN stm { $$ = A_If(EM_tokPos, $2, $4, NULL); }
  | BEGINN stmts END { $$ = A_Seq(EM_tokPos, $2); }
  ;
```

#figure(
  image("figure/lab8_result.png", width: 100%),
  caption: "实验八运行结果"
)

实验运行结果如图所示，能够正确输出语法分析树结构，并通过所有平台测试用例。

= 实验中遇到的问题、难点及解决方案
// TODO:yzr
#cprob[文法定义和AST构造函数的匹配错误，实验要求生成语法分析树，但最初的文法定义和AST构造函数不匹配。][小组成员仔细检查文法定义，修改确保其与AST构造函数的参数和结构一致，最后解决。]
#cprob[parser.l 文件中的 token 定义与 parser.y 文件中的文法规则不一致，导致语法分析器无法正确识别关键字和符号。][在 parser.l 文件中添加缺失的关键字和符号的 token 定义，并确保所有 token 名称与 parser.y 文件中的定义一致。]
#cprob[一开始没发现ast.c 文件中的构造函数不完整，未正确初始化结构体成员，导致语法树生成错误。][后面小组成员完善了 ast.c 文件中的构造函数，确保每个函数正确初始化结构体成员，包括设置节点类型、位置和相关值。]

= 感想和收获
// TODO:yzr
实验八中，我们小组深入理解了编译器设计中语法分析与抽象语法树AST生成的核心概念。实验中我们遇到了一些问题和报错，比如文法定义与AST构造函数的匹配问题、词法分析器未正确定义token、语法分析器的冲突、AST构造函数的不完整实现以及类型未声明问题。这些问题主要集中在迁移前面实验的代码后没有检查变量命名的一致性，以及看漏了新实验的一些新规定新定义。通过仔细分析文法规则和AST结构，我们修正了文法定义以匹配AST构造函数并完善了`parser.l`文件中的token定义。对于语法分析器的冲突，我们重新审视文法并利用Yacc/Bison的优先级和结合性指令加以解决，补充了`ast.c`文件中的构造函数实现，确保每个节点正确初始化。检查报错在哪这一块儿耗费了我们小组很多时间，不过这些也提醒我们之后迁移前面实验代码后一定要检查前后实验变量名的一致性，同时也增强了团队协作和问题解决的能力。

= 小组分工情况
- 梁子毅：
  - 统筹实验进度，整合编写实验报告

- 易率：
  - 实验重点内容的

- 庾子睿：
  - 问题和感想内容的撰写

- 曹嗣弘：
  - 实验细节思考，完善代码

- 汪涛：
  - 验证输出格式是否符合要求 ，修复未闭合引号、多行字符串等边界问题
