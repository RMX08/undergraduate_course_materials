#import "./template.typ": *
#import "@preview/cuti:0.2.1": show-cn-fakebold
#show: show-cn-fakebold
#set text(font: ("Times New Roman", "SimSun"))

#let title = "编译原理实验报告"
#let sub_title = (
  (name: "实验一", content: "学习Lex并使用Flex调试1"),
  (name: "实验二", content: "学习Lex并使用Flex调试2"),
)
#let author = "lzy"
#let members = (
  (name: "梁子毅", id: "22090001041"),
  (name: "庾子睿", id: "22020007135"),
  (name:"汪涛", id:"21020007089"),
  (name:"易率", id:"22090041073"),
  (name:"曹嗣弘",id:"22020007004")
)
#let pair_members = none
#let date = datetime(
  year: 2025,
  month: 4,
  day: 18,
)

#show: assign_class.with(title, sub_title,author, members, pair_members, date)

#my_heading("实验一：学习Lex并使用Flex调试1")
= 实验目的
熟悉educoder在线实验环境的使用，学习使用Lex写简单的词法分析程序，会在educoder在线实验环境下使用Flex编写调试Lex写的程序

= 实验内容
== 第一部分
编写一个词法分析程序，它能对输入的一行字符流进行词法分析，依次识别出其中的关系运算符、圆括号和其他符号，并输出对应的记号序列。例如，若输入的字符流为：
`if (a<=b) a=b`
则输出：
```shell
(OTHER,3)(BRACKETS,"(")(OTHER,1)(RELOP,"<=")(OTHER,1)(BRACKETS,")")(OTHER,2)(RELOP,"=")(OTHER,1)
```
这里`(OTHER,3)`表示一个非关系运算符、非括号的子串，3表示长度，长度统计时可能含有空格等空白符。

右侧编辑器中的代码已经可以识别出关系运算符和其他符号，请你补充代码，使其能够识别圆括号并输出

== 第二部分
阅读右侧编辑器中的*代码和注释*，读懂含义并修改该代码，在其基础上，根据表一增加如下记号：
- 左右大小括号：{ } ( )
- 将关系算符改写成C中的形式
- 分号、赋值号：;  \=
- 关键字：`if else`
- 双斜线表示的注释：\/\/
- 算术运算符号：+ - \* \/
- 将标识符改为可含有下划线，并且可以以下划线开头
- 将注释内容忽略
  如 @t1 ：简单语言的词法记号

#figure(
  table(
    columns: (auto, auto, auto, auto),
    inset: 2pt,
    align: horizon,
    table.header(
      [*类型*], [*词法记号*], [*类型*],[*词法记号*]
    ),
    [标识符], [ID], [关系运算符], [RELOP],
    [数字], [NUM], [\{], [LBRACE],
    [\+], [PLUS], [\}], [RBRACE],
    [-], [MINUS], [\(], [LPAREN],
    [\*], [TIMES], [\)], [RPAREN],
    [\/], [DIV], [\;], [SEMICOLON],
    [\=], [ASSIGN], [if], [IF],
    [do], [DO], [else], [ELSE],
    [while], [WHILE], [其他], [ERRORCHAR],
  ),
  caption: "简单语言的词法记号",
)<t1>


= 实验要求
== 第一部分要求
- 输入输出的要求如下：
  - 输入为一行，换行符标识输入字符流结束；
  - 输出为一行，中间不包含任何空格符。

== 第二部分要求
- 输入为若干字符，表示一个简单语言的源代码。
- 输出为若干行，包含若干记号序列，每个记号序列包含枚举值和属性值，枚举值和属性值中间用逗号隔开，逗号后带有一个空格，每个记号序列间用小括号和空格隔开。每输出五个记号序列后，换一次行
- 测试输入
```
//代码开始
while a >= -1.2E-2
do b<=2
/* 代码结束。
*/
```
- 预期输出
```shell
(IF, "if") (LPAREN, "(") (ID, "_x") (RELOP, "==") (NUM, "1.2E-2") 
(RPAREN, ")") (LBRACE, "{") (ID, "x") (ASSIGN, "=") (NUM, "1") 
(PLUS, "+") (NUM, "2") (MINUS, "-") (NUM, "3") (TIMES, "*") 
(NUM, "4") (DIV, "/") (NUM, "5") (SEMICOLON, ";") (RBRACE, "}") 
(ELSE, "else") (IF, "if") (LPAREN, "(") (ID, "_x") (RELOP, "!=") 
(NUM, "1.2") (RPAREN, ")") (LBRACE, "{") (ID, "x_1") (ASSIGN, "=") 
(NUM, "1") (SEMICOLON, ";") (RBRACE, "}") (WHILE, "while") (LPAREN, "(") 
(ID, "a_b") (RELOP, ">=") (NUM, "1.2E-2") (RPAREN, ")") (DO, "do") 
(ID, "_b") (RELOP, "<") (NUM, "2") (SEMICOLON, ";") (NUM, "1") 
(ERRORCHAR, ".") (ERRORCHAR, ".") (NUM, "2") 
```
= 实验过程及重点内容
== 第一部分<s4_part1>
这里需要匹配括号，使用如下步骤：
+ 先在定义段定义括号`#define BRACKETS 3`和正规匹配的内容`brackets   \(|\)`
+ 在规则段中添加规则`{brackets} {return BRACKETS;}`
+ 在辅助函数中添加`case BRACKETS: fprintf(yyout, "(BRACKETS,\"%s\")", yytext);break;`

== 第二部分
- 分别匹配实验要求匹配的内容
- 先在定义段定义需要匹配的内容，如@lab1_part2_define
- 在规则段中添加规则，如@lab1_part2_translate
- 最后在辅助函数中添加对应的输出语句，如@lab2_function
== 词法分析器的状态
#info[词法分析器在匹配正规式时，可以在不同状态（或环境）下进行][
  进入一个状态后，词法分析器会根据输入的字符流和当前状态来决定下一个状态和要执行的动作
]
- 使用词法分析器的状态来匹配注释
- 书写规则如下
  ```flex
  <state1, state2> p0 {action0;}
  <state1> p1 {action1;}
  //这两行词法规则表示：在状态 state1 和 state2 下，匹配正规式 p0 后执行动作 action0，
  //而只有在状态 state1 下，才可以匹配正规式 p1 后执行动作 action1。 如果不指明状态，默认
  //情况下处于初始状态 INITIAL
  ```
- `INITIAL`表示初始状态，`<state1, state2>`表示在state1状态下匹配到p0后，进入state2状态
- `BEGIN`是一个预定义的宏，可以用来切换状态
- 示例：
  ```flex
    …
    %s c_comment
    …
    %%
    <INITIAL>“/*” {BEGIN c_comment;}
    …
    <c_comment>“*/” {BEGIN 0;}
    <c_comment>. {;}
  ```
  - 当匹配到`/*`时，进入`c_comment`状态
  - 当匹配到`*/`时，返回初始状态(0即INITIAL)
  - 当匹配到其他字符时，什么都不做（`{;}`)
= 实验结果
#figure(
    grid(
    columns: (auto, auto),
    gutter: 0pt,
    figure(
    image("figure/lab1_part1_result.png", width: 80%),
    caption: "实验结果1截图",
    ),
    figure(
    image("figure/lab1_part2_result.png", width: 80%),
    caption: "实验结果2截图",
    )
  )
)<lab1_result>
+ 第一部分其他重点内容如@s4_part1 中所述
+ 第二部分其他重点内容
  #figure(
    grid(
      columns: (auto, auto),
      gutter: 0pt,
      image("figure/lab1_part2_define.png", width: 56%),
      image("figure/lab1_part2_define2.png", width: auto),
    ),
    caption: [第二部分定义部分截图]
  )<lab1_part2_define>

#figure(
  grid(
    columns: (auto, auto),
    gutter: 0pt,
    image("figure/lab1_part2_translate.png", width: 100%),
    image("figure/lab1_part2_translate2.png", width: 80%),
  ),
  caption: [第二部分翻译部分截图]
)<lab1_part2_translate>
#figure(
  image("figure/lab1_part2_function.png", width: auto),
  caption: "辅助函数部分截图",
)<lab2_function>
= 实验中遇到的问题、难点及解决方案
== 第一部分
+ lex/flex是通过处理其源文件来生词法和语法分析器的，源文件的扩展名为.l (小写字母L），其语法被分为三个部分
  #info[lex/flex的语法结构][
    ```flex
      /* 定义段 */  
      %{  
      %}  
      %%  
      /* 规则段 */  
      %%  
      /* 用户子程序段 */    
    ```
    + 定义段：包含了C语言的头文件和一些宏定义，用户可以在这里定义一些常量和变量，放在`%{`和`%}`之间的代码会被直接复制到生成的C文件中。
    + 规则段：包含了正则表达式和对应的动作，正则表达式用于匹配输入的字符流，动作是当正则表达式匹配成功后执行的代码。规则段以`%%`分隔。
    + 用户子程序段：包含了用户自定义的函数和变量，放在`%%`之后的代码会被直接复制到生成的C文件中。
  ]

  #info[正规匹配][
    #figure(
      table(
        columns: (auto, auto),
        inset: 8pt,
        align: horizon,
        table.header(
          [类型], [*词法记号*], 
        ),
        [\|], [或], 
        [\[\]], [括号中的内容取其一],
        [\-], [a-z： ascii码中介于a-z包括a.z的字符], 
        [\\], [转义符],
        [\d], [0-9： ascii码中介于0-9包括0-9的字符], 
        [\+], [1或者多个字符],
        [\*], [0或者多个字符],
        [\?], [0或者1个字符],
        [\.], [除了\\n之外的所有字符，等价于\^\\n],
        [\^], [除此之外的其余字符],
      ),
      caption: "正规匹配符号对应含义",
    )<t2>    
  ]

== 第二部分
#cprob[单行注释处理没处理好][
  一开始使用`<INITIAL>"//"[^\n]*			{BEGIN COMMENT; BEGIN INITIAL;}`来处理单行注释，后续理解深入之后发现与`<INITIAL>"//"[^\n]*			{;}`等效
]
#cprob[匹配顺序问题][
  `ERRORCHAR`的匹配要放在最后面，所有放在`ERRORCHAR`之后的都无法匹配上
]
= 感想和收获
== 第一部分
- 学习了Lex的基本语法和使用方法，了解了Lex的工作原理和流程
- 实验比较简单，基本上熟悉一下flex的语法就可以完成了

== 第二部分
- 本次实验主要是熟悉Lex的语法和使用方法，了解了Lex的工作原理和流程
- 比实验1复杂一些，主要体现在了对注释的处理上，使用了状态机的概念来处理注释
- 明确了Lex中使用状态的方法，在后续实验中将弄够用上

= 小组分工情况
== 第一部分
- 各个成员独立完成了第一部分，并在最后进行了讨论，提出了各自的想法和建议。由组长负责最后的报告撰写汇总

== 第二部分
- 各个成员独立完成了第二部分，并对如何忽略注释内容进行讨论，提出了各自想法。由组长负责最后的报告撰写汇总


/***   PART II    ***/
#my_heading("实验二：学习Lex并使用Flex调试2")

= 实验目的
熟悉在线开发环境的使用，学习使用lex写简单的词法分析程序，会使用flex调试lex写的程序

= 实验内容
== 第一部分
在【实验一】所改写的程序的基础上增加识别string记号。string是字符串，如果"出现在字符串中，则必须转义，写成\\\"形式；如果\\出现在字符串中，也必须转义，写成\\\\形式

== 第二部分
写一个lex程序，它读入一个文本序列，将该文本中的所有的单独或连续的一段空白（包括一个或多个空格、制表、换行组成的空白）都替换成一个空格
== 第三部分
写一个lex程序，它读入一个c语言文件，将其中所有的float关键字都替换成double关键字
= 实验要求
== 第一部分
在右侧编辑器补充代码，实现对输入文本中string记号的识别，设计识别string记号的的词法分析器

输入输出的要求如下：
平台的输入为若干行，每行有若干字符，表示一个合法的字符串或者其他字符序列。可能包含注释行和空行。

你的输出应为若干行，包含若干记号序列，每个记号序列包含枚举值和属性值，枚举值和属性值中间用逗号隔开，逗号后带有一个空格，每个记号序列间用小括号和空格隔开。每行列出五个记号序列，你的枚举值的名称和大小写应与【实验一】表格里一一对应

测试输入：
```c
/* 我是一条注释 */
"helloworld"
name\"
/* 上面有一行是空行 */
"string4\n\'\0\a"
// 不能将string5\识别为字符串，但可以识别为ID。错误的字符应给出ERROR提示。
"string5\"
```

预期输出：
```shell
(STRING, "helloworld") (ID, "name") (ERRORCHAR, "\") (ERRORCHAR, """) (STRING, "string4\n\'\0\a")
(ERRORCHAR, """) (ID, "string5") (ERRORCHAR, "\") (ERRORCHAR, """) 
```

== 第二部分
在右侧编辑器补充代码，实现要求：输入为一个文本序列；在终端输出新的文本序列，该文本序列在原文本的基础上将单独或连续的空白变成一个空格

*输入输出的要求如下：*

平台的输入为若干行，表示一个文本序列。可能包含注释行和空行。
你的输出应为若干行，表示替换后的文本

- 测试输入：
  ```
  whilespace3begin   whitespace3end
  table3begin            table3end
  newline3begin
  newline3end
  wtnbegin     
  wtnend
  ```
- 预期输出：
  ```
  whilespace3begin whitespace3end table3begin table3end newline3begin newline3end wtnbegin wtnend
  ```
== 第三部分
在右侧编辑器补充代码，实现要求：输入为一个c语言文本序列；在终端输出新的c语言文本序列，该文本序列在原文本的基础上将float关键字替换成double关键字。

注意：必须是float关键字，如果是afloat或者floata这样的id不可以被替换为adouble和doublea。注释里的float也不能被替换

*输入输出的要求如下：*

- 测试输入：
```c
// 注释里的float不应该被替换
int main()
{
    float myfloat = 1;
    double mydouble = 2;
    float myfloat2 = (float)mydouble;
    return 0;
}
```

- 预期输出：
```c
// 注释里的float不应该被替换
int main()
{
    double myfloat = 1;
    double mydouble = 2;
    double myfloat2 = (double)mydouble;
    return 0;
}
```
= 实验过程及重点内容
== 第一部分<lab2_part1_important>
+ 在定义部分，定义STRING:
  ```c
  // 定义
  #define STRING           25
  // 定义匹配规则
  ...
  string  \"({letter}|{digit}|\\.)*\"
  ...
  ```
  在这个匹配下，只能匹配到转义符语义的\\，其他的类似多余双引号，换行双引号都无法匹配
+ 翻译部分 `{string}            {yylval = STRING; return (STRING);}`
+ 辅助函数部分 `case STRING: fprintf(yyout, "(STRING, %s) ", yytext);break;`
  - 这里需要注意，`yytext`会自己记录string的双引号，所以`fprint`中不增加双引号
== 第二部分<lab2_part2_important>
只需要在定义和翻译部分定义匹配空白的规则即可

  ```flex
  ...
      /* 请在这里补充代码 */
  ws  ([ \t| \n]+)
  %%
      /* 请在这里补充代码  */
      
  {ws}    { printf(" "); }

  .					{ECHO;}
  ...
  ```

这里`ws`匹配了所有空格或换行一次或者多次，在翻译部分，当出现ws的时候，在标准输入中打一个空格
== 第三部分<lab2_part3_important>
// TODO
+ 先确定需要做到什么效果：
  - 需要匹配到
    - 独立的`float`
    - 括号里的`(float)`
  - 不要匹配到
    - `" "`中的float
    - 变量里面的float，即前后都有别的符号直接连接的float

+ 探索匹配的正规式，这里我们可以使用相关的在线匹配工具，如#link("https://www.jyshare.com/front-end/854/")[jyshare正则匹配工具]，经过实践，找到一个除了没法忽略`" "`中的内容，其他都可以实现的式子`([^a-zA-Z0-9_])float([^a-zA-Z0-9_])`
+ 在这里，双引号中的内容可以简单被忽略，因此可以在匹配多行注释的地方加入匹配双引号
  - 当匹配双引号的前引号，进入`COMMENT`状态，忽略其中的所有内容，当再匹配到后引号的时候，回到`INITIAL`状态
+ 每次匹配到float的时候，都调用`PRINT_DOUBLE()`函数
= 实验结果
#figure(
    grid(
    columns: (auto, auto, auto),
    gutter: 0pt,
    figure(
      image("figure/lab2_part1_result.png", width: 80%),
      caption: "实验结果1截图",
    ),
    figure(
      image("figure/lab2_part2_result.png", width: 80%),
      caption: "实验结果2截图",
    ),
    figure(
      image("figure/lab2_part3_result.png", width: 80%),
      caption: "实验结果3截图",
    ),
  )
)<lab2_result>

+ 第一部分其他重点内容如@lab2_part1_important 所示
+ 第二部分其他重点内容如@lab2_part2_important 所示
  - 具体如图@lab2_part2_process
  #figure(
    image("figure/lab2_part2_process.png", width:56%),
    caption: [实验2第二部分内容]
  )<lab2_part2_process>
+ 第二部分重点内容如@lab2_part3_important 所示
  - 具体如图@lab2_part2_process
  #figure(
    image("figure/lab2_part3_process.png", width:56%),
    caption: [实验2第三部分内容, 但是其实第一行状态定义并没有用到]
  )<lab2_part3_process>
== 词法分析器的状态2
`%s`后面可以跟一个标识符，用来定义一个新的状态。在本次实验中，`%s COMMENT` 定义了一个名为 `COMMENT` 的状态，`%s LINECOMMENT` 定义了一个名为 `LINECOMMENT` 的状态


#info[
  `%s` 的简介
][
  - *是什么*： `%s` 是 flex 中用于定义 “exclusive”（排他的）状态的关键字，它后面的标识符就是定义的状态名。当处于一个 %s 定义的状态时，只有在该状态下定义的规则才会被考虑匹配输入

  - *什么时候使用*：使用 `%s` 可以区分不同的词法分析场景，避免规则之间的冲突。例如在处理注释时，进入相应的状态后，可以只匹配注释相关的内容，而忽略其他词法元素，从而更准确地进行词法分析

  - *如何使用*：`%s 状态名`

]

#info[
  `%x` 的简介
][
  - *是什么*：`%x` 是 flex 中用于定义 “inclusive”（包容的）状态的关键字。`%x` 定义的状态可以和其他状态（包括 INITIAL）同时激活
  
  - *什么时候使用*：`%x` 定义的状态可以用于处理嵌套或需要同时满足多个条件的复杂场景。例如在处理字符串中的转义字符时，可以使用 `%x` 定义的状态来处理转义字符，同时仍然可以匹配其他字符串内
  
  - *如何使用*：`%x 状态名`

]
= 实验中遇到的问题、难点及解决方案
== 第一部分
#cprob[
  如何匹配转义字符
][
  先匹配反斜杠，再匹配任意字符即可
]
== 第二部分
比较简单，没有什么问题
== 第三部分
// TODO
#cprob[如何不匹配到双引号中的float][
  尝试了负向后瞻`(?<!")`和负向前瞻`(?!")`，并没有解决问题，最后还是将`""`放在注释状态中相对比较好处理
]

剩下的还有一些小问题，但是不影响通过测试：
#cprob[当测试样例中出现如\+等没在匹配规则中忽略的内容时候，会错误匹配到][
  解决手段也比较简单，直接在匹配规则中改就可以
]
   
= 感想和收获
+ *转义字符处理*：需区分`\"`（字符串内引号）和"（字符串结束符）通过状态机进入STRING状态后，优先匹配转义序列`（\\[\\"]）`，再匹配普通字符。

+ *空白合并逻辑*：发现`{ws} printf(" ")`会遗漏换行符，导致输出全部合并为一行，添加\n匹配规则，保留原有换行结构。

+ *精准替换float*：需避免替换变量名（如afloat）和注释中的float

= 小组分工情况
- 梁子毅：
  - 统筹实验进度，整合编写实验报告

  - 主要任务：负责第三部分（替换C语言中的float关键字），设计状态机逻辑，处理注释/字符串中的例外情况，整合各组员代码

  - 辅助任务：协助调试第一部分转义字符问题

- 曹嗣弘：
  - 主要任务：第一部分字符串识别

  - 设计STRING正则表达式，处理\"和\\转义

- 汪涛：

  - 主要任务：第一部分测试与优化

  - 验证输出格式是否符合要求 ，修复未闭合引号、多行字符串等边界问题

- 易率：

  - 主要任务：第二部分空白替换

  - 编写ws规则匹配连续空白，测试换行符、制表符等混合空白场景

- 庾子睿：

  - 主要任务：第三部分辅助开发

  - 编写正则表达式匹配独立float关键字，处理类型转换场景（如(float)替换为(double)）