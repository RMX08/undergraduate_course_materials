import json
from config import config
from mqtt_client import MQTTClient


def main():
    mqtt_client = MQTTClient(
        mqtt_host=config.mqtt_host,
        mqtt_port=config.mqtt_port,
        username=config.mqtt_username,
        password=config.mqtt_password,
        api_host='http://' + config.http_host + ':' + str(config.http_port)
    )

    print('步骤1：从JSON加载传感器配置')
    
    try:
        with open('sensors_config.json', 'r', encoding='utf-8') as f:
            sensors_config = json.load(f)
    except FileNotFoundError:
        print("✗ 找不到 sensors_config.json 文件")
        return False
    except json.JSONDecodeError as e:
        print(f"✗ JSON格式错误: {e}")
        return False

    if not sensors_config:
        print("✗ 传感器配置为空")
        return False

    print(f"✓ 传感器数量: {len(sensors_config)}")

    for sensor in sensors_config:
        global_id = sensor.get("globalId")
        if global_id:
            mqtt_client.sensor_map[global_id] = sensor

    print(f"✓ 已加载 {len(mqtt_client.sensor_map)} 个传感器")
    for i, (gid, info) in enumerate(list(mqtt_client.sensor_map.items())):
        print(f"  GlobalID {gid}: {info.get('deviceName')} - {info.get('name')} ({info.get('unit')})")

    mqtt_client.sensor_loaded = True
    mqtt_client.gate_no = config.gate_no
    mqtt_client.use_filtered_display = True
    print(f"✓ 网关号: {mqtt_client.gate_no}")

    print(f"\n✅ 传感器信息加载完成")
    
    if not mqtt_client.connect_mqtt():
        return
    
    mqtt_client.send_commands()
    mqtt_client.start_listening()


if __name__ == '__main__':
    main()
