"""
MQTT网关客户端
功能：连接MQTT，发送采集命令，接收并解析传感器数据
"""

import paho.mqtt.client as mqtt
import json
import time
from device_api_client import DeviceAPIClient


class MQTTClient:
    def __init__(self, mqtt_host="192.168.0.2",
                 mqtt_port=1883,
                 api_host="http://192.168.0.2:8888",
                 username='appback',
                 password='ouccs'):
        """初始化MQTT客户端
        Args:
            mqtt_host: MQTT服务器地址
            mqtt_port: MQTT服务器端口
            api_host: API服务器地址（完整URL，如 http://192.168.1.100:8888）
        """
        # MQTT配置
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        self.username = username
        self.password = password

        # API客户端
        self.api = DeviceAPIClient(base_url=api_host)

        # MQTT客户端
        self.client = mqtt.Client()
        self.client.username_pw_set(self.username, self.password)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message

        # 数据存储
        self.gate_no = None
        self.sensor_map = {}  # {globalId: sensor_info}

        # 状态标志
        self.sensor_loaded = False  # 传感器信息是否已加载
        self.command_sent = False  # 命令是否已发送
        self.use_filtered_display = False  # 是否只显示JSON配置的传感器

    def on_connect(self, client, userdata, flags, rc):
        print(client,userdata,flags,rc,'chas')
        """MQTT连接成功回调"""
        if rc == 0:
            print(f"✓ MQTT连接成功: {self.mqtt_host}:{self.mqtt_port}")
            # 订阅传感器数据主题
            topic = f"/gate_{self.gate_no}/dass/upload_SensorData"
            client.subscribe(topic)
            print(f"✓ 已订阅主题: {topic}\n")
        else:
            print(f"✗ MQTT连接失败，错误码: {rc}")

    def on_message(self, client, userdata, msg):
        print(client,userdata,msg,'chass')
        """接收MQTT消息回调"""
        # 检查是否已完成初始化
        if not self.sensor_loaded or not self.command_sent:
            print(f"⏳ 收到消息但尚未完成初始化，跳过...")
            return

        print("=" * 80)
        print(f"📥 收到消息 [{time.strftime('%H:%M:%S')}]")
        print(f"主题: {msg.topic}")
        print("-" * 80)

        try:
            # 解析JSON消息
            data = json.loads(msg.payload.decode('utf-8'))
            print(f"原始数据: {json.dumps(data, ensure_ascii=False)}\n")

            # 提取传感器数据字符串
            if 'result' in data and 'data' in data['result']:
                sensor_data_str = data['result']['data']
                if self.use_filtered_display:
                    self.parse_and_display_filtered(sensor_data_str)
                else:
                    self.parse_and_display(sensor_data_str)

        except Exception as e:
            print(f"✗ 解析错误: {e}")

        print("=" * 80 + "\n")

    def parse_and_display(self, data_str):
        """
        解析传感器数据并显示（显示所有传感器）
        格式: "START#T,2025/11/19 21:44:06.967,12:8440.0@11:8440.0@..."
        """
        print("📊 解析后的传感器数据:")
        print("-" * 80)

        # 提取传感器数据部分（第三个逗号后的内容）
        if ',' in data_str:
            parts = data_str.split(',', 2)
            if len(parts) >= 3:
                sensor_part = parts[2]  # "12:8440.0@11:8440.0@..."

                # 按 @ 分割每个传感器
                items = sensor_part.split('@')

                for item in items:
                    if ':' in item:
                        try:
                            # 解析 globalId:value
                            global_id_str, value_str = item.split(':', 1)
                            global_id = int(global_id_str)
                            value = float(value_str)

                            # 从映射表获取传感器信息
                            sensor = self.sensor_map.get(global_id, {})
                            name = sensor.get('name', 'Unknown')
                            unit = sensor.get('unit', '')
                            device = sensor.get('deviceName', 'Unknown')

                            # 显示
                            print(f"  GlobalID {global_id:>3} | {device:<12} | {name:<8} | {value:>8.1f} {unit}")

                        except (ValueError, IndexError):
                            continue

    def parse_and_display_filtered(self, data_str):
        """
        解析传感器数据并显示（只显示JSON配置的传感器）
        格式: "START#T,2025/11/19 21:44:06.967,12:8440.0@11:8440.0@..."
        """
        print("📊 解析后的传感器数据:")
        print("-" * 80)

        # 提取传感器数据部分（第三个逗号后的内容）
        if ',' in data_str:
            parts = data_str.split(',', 2)
            if len(parts) >= 3:
                sensor_part = parts[2]  # "12:8440.0@11:8440.0@..."

                # 按 @ 分割每个传感器
                items = sensor_part.split('@')

                for item in items:
                    if ':' in item:
                        try:
                            # 解析 globalId:value
                            global_id_str, value_str = item.split(':', 1)
                            global_id = int(global_id_str)
                            value = float(value_str)

                            # 只显示在sensor_map中配置的传感器
                            if global_id in self.sensor_map:
                                sensor = self.sensor_map.get(global_id, {})
                                name = sensor.get('name', 'Unknown')
                                unit = sensor.get('unit', '')
                                device = sensor.get('deviceName', 'Unknown')

                                # 显示
                                print(f"  GlobalID {global_id:>3} | {device:<12} | {name:<8} | {value:>8.1f} {unit}")

                        except (ValueError, IndexError):
                            continue

    def send_order(self, global_ids, loop=1000):
        """
        发送采集命令
        
        Args:
            global_ids: 要采集的传感器globalId列表
            loop: 循环间隔（毫秒）
        """
        if not self.gate_no:
            print("✗ 网关号未设置")
            return

        # 构建order命令
        order = self.build_order(global_ids)

        # 构建消息
        message = {
            "msg_id": str(int(time.time() * 1000)),
            "type": "getdata",
            "data": {
                "order": order,
                "loop": loop
            }
        }

        # 发送
        topic = f"/gate_{self.gate_no}/dass/order"
        result = self.client.publish(topic, json.dumps(message, ensure_ascii=False))

        # 确保消息发送成功
        self.client.loop(timeout=0.5)

        print(f"\n✓ 发送命令到: {topic}")
        print(f"  Order: {order}")
        print(f"  Loop: {loop}ms")
        print(f"  GlobalIDs: {global_ids}")
        print(f"  发送结果: {result.rc}")

        # 标记命令已发送
        self.command_sent = True
        print(f"\n✅ 命令发送完成，开始接收数据...")

    def build_order(self, global_ids):
        """
        构建order命令字符串
        格式: #*A{Value1_globalId}AA{Value2_globalId}A...&{CRC}$
        例如: #*A4AA5AA6A&{CRC}$
        """
        if not global_ids:
            return ""

        # 构建命令：#*A + 每个globalId用A分隔 + A
        cmd = "#*A"
        for gid in global_ids:
            cmd += f"{gid},A"

        crc = 0
        for char in cmd:
            crc ^= ord(char)

        return f"{cmd}&{crc:02X}$"

    def connect_mqtt(self):
        """连接MQTT服务器"""
        print(f"\n🔌 步骤2: 连接MQTT服务器")
        print("-" * 80)
        try:
            self.client.connect(self.mqtt_host, self.mqtt_port, 60)
            # 注意：这里不使用 loop_start()，改用 loop() 进行连接握手
            self.client.loop(timeout=2.0)  # 处理连接和订阅
            return True
        except Exception as e:
            print(f"✗ 连接失败: {e}")
            return False

    def send_commands(self):
        """发送采集命令"""
        print(f"\n📤 步骤3: 发送采集命令")
        print("-" * 80)

        # 等待MQTT完全就绪
        print("等待MQTT连接稳定...")
        time.sleep(1)

        # 获取所有globalId
        global_ids = list(self.sensor_map.keys())

        print("global_ids", global_ids)
        if global_ids:
            # 发送命令
            self.send_order(global_ids[:100], loop=1000)  # 前100个传感器
        else:
            print("✗ 没有可用的传感器")

    def start_listening(self):
        """开始监听消息"""
        print(f"\n👂 步骤4: 监听传感器数据")
        print("-" * 80)

        # 等待命令处理完成
        print("等待网关响应...")
        time.sleep(1)

        print("开始循环接收消息（按 Ctrl+C 退出）...\n")

        try:
            self.client.loop_forever()
        except KeyboardInterrupt:
            print("\n\n正在断开连接...")
            self.client.disconnect()
            print("已断开连接")
        except Exception as e:
            print(f"\n✗ MQTT循环错误: {e}")
            self.client.disconnect()
