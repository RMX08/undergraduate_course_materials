class config:
    mqtt_host: str = "192.168.0.2"
    mqtt_port: int = 1883
    mqtt_username: str = "appback"
    mqtt_password: str = "ouccs"
    http_host: str = '192.168.0.2'
    http_port: int = 8888
    gate_no: int = 1
    description: str = '配置文件示例'
