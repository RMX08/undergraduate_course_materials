import requests
import json
from typing import Dict, List, Any


class DeviceAPIClient:
    """设备管理API客户端"""

    def __init__(self, base_url: str = "http://192.168.0.2:8888"):
        """
        初始化API客户端
        
        Args:
            base_url: API基础URL
        """
        self.base_url = base_url
        self.session = requests.Session()

    def get_all(self, page: int = 1, limit: int = 10,
                user_id: int = 1, gateway_no: int = 1,
                instrumentType: str = '', model: str = '',
                interfaceType: str = '', sortType: str = '') -> Dict[str, Any]:
        """
        获取所有设备信息
        
        Args:
            page: 页码
            limit: 每页数量限制
            user_id: 用户ID
            gateway_no: 网关编号
            instrumentType: 仪器类型
            model: 设备型号
            interfaceType: 接口类型
            sortType: 排序类型
            
        Returns:
            API响应数据字典
        """
        url = f"{self.base_url}/starLightOS/device_management/getall"
        params = {
            "page": page,
            "limit": limit,
            "userId": user_id,
            "gatewayNo": gateway_no,
            "instrumentType": instrumentType,
            'model': model,
            'interfaceType':interfaceType,
            'sortType':sortType
        }

        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"获取设备列表失败: {e}")
            return {}

    def get_filters(self) -> List[Dict[str, Any]]:
        """
        获取单个设备的传感器信息（包括globalId）

        Args:
            instrument_id: 设备ID

        Returns:
            传感器信息列表
        """
        url = f"{self.base_url}/starLightOS/device_management/getfilters"
        try:
            response = self.session.get(url)
            response.raise_for_status()
            data = response.json()

            if data.get("success"):
                return data.get("data", [])
            else:
                print(f"获取传感器信息失败: {data.get('message')}")
                return []
        except requests.exceptions.RequestException as e:
            print(f"获取传感器信息失败: {e}")
            return []

    def get_sensor_by_instrument(self, device_ids: List[int],
                                 page: int = 1, limit: int = 10) -> Dict[str, Any]:
        """
        根据设备ID列表获取传感器结果
        
        Args:
            device_ids: 设备ID列表
            page: 页码
            limit: 每页数量限制
            
        Returns:
            API响应数据字典
        """
        url = f"{self.base_url}/starLightOS/device_management/getsensorbyinstrument"

        # 构建instrumentInfo JSON字符串
        instrument_info = {
            "instrumentInfo": [{"ID": device_id} for device_id in device_ids]
        }
        str_param = json.dumps(instrument_info, ensure_ascii=False)

        params = {
            "limit": limit,
            "page": page,
            "str": str_param
        }

        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"获取传感器结果失败: {e}")
            return {}
