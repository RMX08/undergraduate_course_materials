# @Time   : 2025/11/28 下午3:52
# @Author : Chas
# @File   : main.py
# @desc   : 案例
# Copyright (c) 2025 Chas-OUC. All Rights Reserved.
from config import config
from mqtt_client import MQTTClient


def main():
    mqtt_client = MQTTClient(mqtt_host=config.mqtt_host, mqtt_port=config.mqtt_port, username=config.mqtt_username,
                             password=config.mqtt_password,
                             api_host='http://' + config.http_host + ':' + str(config.http_port))
    print('步骤1：加载数据')
    gateNo = None
    filters = mqtt_client.api.get_filters()
    if filters['gates'][0]['gateName'] == '默认普通采集网关':
        gateNo = filters['gates'][0]['gateNo']
    response = mqtt_client.api.get_all(gateway_no=gateNo)
    if not response.get("success"):
        print("✗ 获取设备列表失败")
        return False
    devices = response.get("data", [])
    if not devices:
        print("✗ 没有设备")
        return False
        # 获取网关号
    mqtt_client.gate_no = devices[0].get("gateNo")
    print(f"✓ 设备数量: {len(devices)}")
    print(f"✓ 网关号: {mqtt_client.gate_no}")
    device_ids = [d.get("id") for d in devices]
    device_name_map = {d.get("id"): d.get("name") for d in devices}
    sensor_response = mqtt_client.api.get_sensor_by_instrument(device_ids)
    if not sensor_response.get("success"):
        print("✗ 获取传感器信息失败")
        return False
    sensors = sensor_response.get("data", [])
    for sensor in sensors:
        global_id = sensor.get("globalId")
        if global_id:
            instrument_id = sensor.get("instrumentId")
            sensor['deviceName'] = device_name_map.get(instrument_id, "Unknown")
            mqtt_client.sensor_map[global_id] = sensor
    print(f"✓ 传感器数量: {len(mqtt_client.sensor_map)}")
    for i, (gid, info) in enumerate(list(mqtt_client.sensor_map.items())):
        print(f"  GlobalID {gid}: {info.get('deviceName')} - {info.get('name')} ({info.get('unit')})")

    # 标记传感器信息已加载
    mqtt_client.sensor_loaded = True

    print(f"\n✅ 传感器信息加载完成")
    if not mqtt_client.connect_mqtt():
        return
    # 发送采集命令
    mqtt_client.send_commands()
    # 开始监听
    mqtt_client.start_listening()


if __name__ == '__main__':
    main()
